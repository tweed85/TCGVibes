# PandaBananasTCG — Mobile redesign handoff

Implementing the Arcade direction in the existing `TCGVibes-main` Vite/React/TS app. The prototype HTML is React+JSX with inline styles — **not** drop-in code. Use it as a visual + interaction reference and port piece-by-piece.

## What to copy verbatim

1. **`arcade-theme.css`** — paste at the end of `src/styles.css` (or `@import` it from `main.tsx`). Every token your existing CSS already consumes (`--bg`, `--panel`, `--accent`, `--shadow-card`, etc.) is overridden, so the whole app re-skins to Arcade without touching components.

That alone gets you ~70% of the visual change.

## What to port by hand (component-level)

These are the structural moves in the prototype. Each is a small, self-contained change in `src/App.tsx` / `src/ui/CardView.tsx`.

### 1. Mirrored opponent active (centered + big)
The opponent's active should render with **the same component / size as the player's active**, not as a compact card on the side. Tag both with side labels ("Opponent Active" / "Your Active") and tint the opponent with the danger color.

Reference: prototype `BigActive` in `game-screen.jsx` — takes `side="me" | "opp"` and a `selected` prop.

### 2. Framed bench with badge label
Wrap the bench row in a surface container (`background: var(--panel)`, `border: 1px solid var(--border-strong)`, `radius: 14`) with a labeled pill at the top-left ("Your bench · 3 / 5"). This separates the bench visually from the surrounding chrome.

Reference: prototype `GameScreen` → "my bench framed surface".

### 3. Divider band: turn + slot counts + stadium
Collapse the previous separate Stadium row and the separate turn banner into **one strip** between the opponent and player sections:
- Left: a "T4" disc + "Your turn" + the per-turn slot counters (E 0/1, Sup 1/1, Item 0/∞)
- Right: the Stadium chip

Reference: prototype "divider band" inside `GameScreen`.

### 4. Context-aware ActionBar
The bottom action bar should reflect **which of your in-play Pokémon is currently selected**:

| Selection | Buttons |
| --- | --- |
| Active (default) | Attack(s) primary · Ability (if present) · Retreat · End turn |
| Bench card with ability | Ability primary · Promote · End turn |
| Bench card with no ability | "No usable ability" placeholder · Promote · End turn |

Add a selection state to `App.tsx`:
```ts
const [selectedInPlay, setSelectedInPlay] = useState<'active' | number>('active');
```

Bench `<PokemonInPlayView>` becomes clickable → sets `selectedInPlay` to its index. Tapping the active resets to `'active'`.

The ActionBar header shows "ACTIVE · {name}" or "BENCH · {name}" with a back-chip to clear bench selection.

Reference: prototype `ActionBar` + `IconAction` + `ActionBtn` in `game-screen.jsx`.

### 5. Ability indicator on bench cards
Bench Pokémon with an unused ability get a small cyan diamond gem (top-right area of the card) so the player can see at a glance which bench cards are "tappable" for something useful.

Reference: prototype `CompactCard`'s `hasAbility` prop renders the gem.

### 6. Fanned vs grid hand
Hand drawer defaults to a **fanned** layout (subtle rotation, peeking). Tap the "Grid" chip in the drawer header to flip to a 4-column grid. Selecting a hand card lifts it.

Reference: prototype `HandDrawer` + `FannedHand`.

### 7. Bigger primary attack button with damage + cost glyphs
Attack button shows: attack name (display font), damage badge in a dark chip, and energy-type dots showing the cost. Disabled (faded) when cost isn't met.

Reference: prototype `ActionBtn` with `variant="primary"`.

## Files in this folder

```
handoff/
├── README.md              ← you are here
├── arcade-theme.css       ← drop-in CSS, immediate recolor
└── prototype-source/      ← the prototype JSX source for visual reference
    ├── themes.jsx         ← all 3 themes' tokens (Arcade, Paper, Hybrid)
    ├── primitives.jsx     ← Mark, CardPlaceholder, EnergyPip, Pill, Icon
    ├── screens.jsx        ← Home, Pre-game, Builder, Doctor
    └── game-screen.jsx    ← In-game (the most interesting bits)
```

## Suggested order

1. Paste `arcade-theme.css` → check the recolor lands.
2. Restructure the in-game layout (1–3 above) — these are the biggest perceived wins on mobile.
3. Add selection state + context-aware ActionBar (4 + 5).
4. Hand fan/grid (6) — biggest interaction-feel win.
5. Polish: bigger attack button, slot-count display, ability gem indicators.

Let me know if you want me to write any of the actual TSX patches against your repo — I can clone the patterns into `src/App.tsx` / `src/ui/CardView.tsx` directly.
