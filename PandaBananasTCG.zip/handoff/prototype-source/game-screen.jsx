// In-game board screen — the most important mobile view.
// Addresses all in-game pain points from the brief:
//   • larger active card with clear HP/energy/status
//   • cleaner bench row with snap scroll + clearer slots
//   • hand drawer with fanned peek + swipe-up to expand
//   • big thumb-reachable action bar
//   • prominent turn indicator
//   • Stadium / Discard / Prizes as labeled top chips, not buried

function GameScreen({ t, setScreen, layout = 'fanned' }) {
  const [handExpanded, setHandExpanded] = React.useState(false);
  const [selectedHand, setSelectedHand] = React.useState(null);
  // Which of MY in-play Pokémon is currently selected. 'active' = active card,
  // a number 0..4 = bench index. Drives what the ActionBar shows.
  const [selectedInPlay, setSelectedInPlay] = React.useState('active');
  // When the layout tweak changes, drop any in-drawer override so the tweak's
  // intent is what shows on screen.
  React.useEffect(() => { setHandExpanded(false); }, [layout]);

  const myHand = [
    { name: 'Charmander', type: 'fire', hp: 70, kind: 'pokemon' },
    { name: 'Rare Candy', type: 'colorless', hp: null, kind: 'trainer', label: 'Item' },
    { name: 'Boss\'s Orders', type: 'colorless', hp: null, kind: 'trainer', label: 'Sup' },
    { name: 'Iono', type: 'colorless', hp: null, kind: 'trainer', label: 'Sup' },
    { name: 'Fire Energy', type: 'fire', hp: null, kind: 'energy', label: 'E' },
    { name: 'Pidgey', type: 'colorless', hp: 50, kind: 'pokemon' },
    { name: 'Ultra Ball', type: 'colorless', hp: null, kind: 'trainer', label: 'Item' },
  ];

  const myActive = {
    name: 'Charizard ex', type: 'fire',
    hp: 240, maxHp: 330,
    attached: [{ type: 'fire', count: 2 }, { type: 'colorless', count: 1 }],
    status: 'BURN',
    attacks: [
      { name: 'Burning Darkness', damage: 180, cost: ['fire','fire','colorless','colorless'], costMet: 3, costTotal: 4 },
      { name: 'Slash',            damage: 60,  cost: ['colorless','colorless'],                costMet: 3, costTotal: 2 },
    ],
    ability: { name: 'Infernal Reign', kind: 'Ability', once: true, used: false },
  };

  const myBench = [
    { name: 'Charmeleon', type: 'fire', hp: 110, maxHp: 110, attached: 1 },
    { name: 'Pidgeot ex', type: 'colorless', hp: 230, maxHp: 280, attached: 2,
      ability: { name: 'Quick Search', kind: 'Ability', once: true, used: false } },
    { name: 'Charmander', type: 'fire', hp: 70, maxHp: 70, attached: 0 },
    null,
    null,
  ];

  const oppBench = [
    { type: 'psychic', hp: 80, maxHp: 130, attached: 1 },
    { type: 'psychic', hp: 100, maxHp: 100, attached: 0 },
    { type: 'colorless', hp: 70, maxHp: 70, attached: 0 },
  ];

  // Resolve which card the ActionBar should describe.
  const selectedCard = selectedInPlay === 'active'
    ? { ...myActive, location: 'active' }
    : { ...(myBench[selectedInPlay] || {}), location: 'bench', benchIndex: selectedInPlay };

  return (
    <div style={{
      display: 'flex', flexDirection: 'column', height: '100%',
      background: t.bg, color: t.text, overflow: 'hidden', position: 'relative',
    }}>
      {/* ─────────────  OPPONENT SIDE  ───────────── */}
      <div style={{
        background: t.surface,
        borderTop: t.name === 'Arcade' ? `2px solid ${t.danger}` : `1px solid ${t.danger}`,
        borderBottom: `1px solid ${t.border}`,
        padding: '10px 12px 12px',
      }}>
        {/* meta row */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
          <Stack t={t} label="Prizes" count={4} color={t.danger} size="sm" />
          <Stack t={t} label="Deck" count={30} size="sm" />
          <Stack t={t} label="Discard" count={8} size="sm" />
          <div style={{ flex: 1 }} />
          <div style={{
            display: 'flex', alignItems: 'center', gap: 5,
            background: t.surfaceSunken, padding: '3px 8px', borderRadius: 999,
          }}>
            <div style={{ width: 6, height: 6, borderRadius: 999, background: t.danger }} />
            <span style={{ fontFamily: t.fontBody, fontWeight: 600, fontSize: 10.5, color: t.text }}>CPU</span>
            <span style={{ fontFamily: t.fontMono, fontSize: 10, color: t.textMute }}>5 hand</span>
          </div>
        </div>

        {/* opp bench centered (above the active, mirrored) */}
        <div style={{
          display: 'flex', gap: 6, justifyContent: 'center',
          padding: '0 0 8px',
        }}>
          {oppBench.map((c, i) => (
            <CompactCard key={i} t={t} hp={c.hp} maxHp={c.maxHp} type={c.type} attached={c.attached} mini />
          ))}
          {oppBench.length < 5 && Array.from({ length: 5 - oppBench.length }).map((_, i) => (
            <div key={'e' + i} style={{
              width: 44, height: 60, borderRadius: t.radius - 4,
              border: `1.5px dashed ${t.border}`,
            }} />
          ))}
        </div>

        {/* opp BIG ACTIVE centered */}
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <BigActive
            t={t} side="opp"
            name="Gardevoir ex" type="psychic"
            hp={150} maxHp={210} attached={[
              { type: 'psychic', count: 2 },
              { type: 'colorless', count: 1 },
            ]}
            status={null}
          />
        </div>
      </div>

      {/* ─────  divider band: turn / slot counts + stadium on the SIDE  ───── */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8,
        padding: '8px 12px',
        background: `linear-gradient(180deg, ${t.surfaceSunken} 0%, ${t.bgSolid} 100%)`,
        borderBottom: `1px solid ${t.border}`,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
          <div style={{
            width: 28, height: 28, borderRadius: 999,
            background: t.accent3, color: '#1f1408',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 11,
            flex: '0 0 auto',
            boxShadow: '0 2px 6px rgba(0,0,0,0.25)',
          }}>T4</div>
          <div style={{ minWidth: 0 }}>
            <div style={{
              fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 11.5,
              color: t.text, lineHeight: 1.1,
              letterSpacing: '-0.005em',
            }}>Your turn</div>
            <div style={{ display: 'flex', gap: 6, marginTop: 2 }}>
              <SlotChip label="E" used={0} max={1} t={t} />
              <SlotChip label="Sup" used={1} max={1} t={t} />
              <SlotChip label="Item" used={0} max="∞" t={t} />
            </div>
          </div>
        </div>
        <button style={{
          display: 'inline-flex', alignItems: 'center', gap: 6,
          background: t.surfaceRaised, border: `1px solid ${t.borderStrong}`,
          borderRadius: 999, padding: '4px 10px 4px 5px',
          cursor: 'pointer', color: t.text, flex: '0 0 auto',
        }}>
          <div style={{
            width: 16, height: 16, borderRadius: 4,
            background: `repeating-linear-gradient(45deg, ${t.accent3} 0px, ${t.accent3} 3px, ${t.accent} 3px, ${t.accent} 6px)`,
          }} />
          <span style={{ fontFamily: t.fontBody, fontWeight: 600, fontSize: 11, color: t.text }}>Crystal Cave</span>
        </button>
      </div>

      {/* ─────────────  MY SIDE  ───────────── */}
      <div style={{ flex: 1, padding: '10px 12px 0', display: 'flex', flexDirection: 'column', gap: 8, minHeight: 0 }}>
        {/* my BIG ACTIVE centered */}
        <div style={{ display: 'flex', justifyContent: 'center' }}>
          <BigActive
            t={t} side="me"
            name={myActive.name} type={myActive.type}
            hp={myActive.hp} maxHp={myActive.maxHp}
            attached={myActive.attached}
            attackHint={myActive.attacks?.[0] ? `${myActive.attacks[0].costMet}/${myActive.attacks[0].costTotal} to attack` : null}
            status={myActive.status}
            selected={selectedInPlay === 'active'}
            onSelect={() => setSelectedInPlay('active')}
          />
        </div>

        {/* my bench — framed surface with explicit label so it doesn't blend
             into the surrounding chrome */}
        <div style={{
          background: t.surface,
          border: `1px solid ${t.borderStrong}`,
          borderRadius: t.radius,
          padding: '8px 8px 10px',
          position: 'relative',
        }}>
          <div style={{
            position: 'absolute', top: -8, left: 12,
            background: t.accent2, color: '#0a1116',
            fontFamily: t.fontBody, fontWeight: 700, fontSize: 9,
            letterSpacing: '0.12em', textTransform: 'uppercase',
            padding: '2px 8px', borderRadius: 999,
          }}>Your bench · 3 / 5</div>
          <div style={{
            display: 'flex', gap: 6, justifyContent: 'center',
            padding: '2px 0 0',
          }}>
            {myBench.map((c, i) => (
              <div key={i} style={{ flex: '0 0 auto' }}>
                {c ? (
                  <button
                    onClick={() => setSelectedInPlay(i)}
                    style={{ background: 'transparent', border: 'none', padding: 0, cursor: 'pointer' }}
                    aria-label={`Bench: ${c.name}`}
                  >
                    <CompactCard
                      t={t} {...c} bench
                      active={selectedInPlay === i}
                      labelTone={selectedInPlay === i ? t.accent2 : undefined}
                      hasAbility={!!c.ability}
                    />
                  </button>
                ) : (
                  <EmptyBench t={t} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* my meta row: prizes / deck / discard / log */}
        <div style={{ display: 'flex', gap: 6, paddingBottom: 2 }}>
          <Stack t={t} label="Prizes" count={5} color={t.accent3} />
          <Stack t={t} label="Deck" count={28} />
          <Stack t={t} label="Discard" count={11} />
          <div style={{ flex: 1 }} />
          <button style={{
            display: 'flex', alignItems: 'center', gap: 4,
            background: t.surfaceSunken, border: `1px solid ${t.border}`,
            borderRadius: 8, padding: '6px 9px',
            cursor: 'pointer',
            fontFamily: t.fontBody, fontWeight: 600, fontSize: 10.5, color: t.textDim,
          }}>
            <Icon name="list" size={11} color={t.textDim} /> Log
          </button>
        </div>
      </div>

      {/* Hand drawer ────────────────────────────────── */}
      <HandDrawer
        t={t}
        cards={myHand}
        expanded={handExpanded}
        onToggle={() => setHandExpanded(v => !v)}
        layout={layout}
        selectedHand={selectedHand}
        setSelectedHand={setSelectedHand}
      />

      {/* Action bar ─────────────────────────────────── */}
      <ActionBar t={t} setScreen={setScreen} selectedCard={selectedCard} onClearSelection={() => setSelectedInPlay('active')} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Big active Pokémon — the focal point. Used for BOTH player + opponent.
// `side="me"` styles with accent border + attack-hint pill;
// `side="opp"` uses a danger-tinted border + no attack hint.
// ─────────────────────────────────────────────────────────────
function BigActive({
  t, side = 'me',
  name = 'Charizard ex', type = 'fire',
  hp = 240, maxHp = 330,
  attached = [{ type: 'fire', count: 2 }, { type: 'colorless', count: 1 }],
  attackHint = null, status = null,
  selected = true, onSelect,
}) {
  const pct = (hp / maxHp) * 100;
  const isOpp = side === 'opp';
  const accent = isOpp ? t.danger : t.accent;
  const ringOn = isOpp || selected;
  return (
    <button
      onClick={onSelect}
      disabled={!onSelect}
      style={{
        all: 'unset',
        width: 290, position: 'relative',
        borderRadius: t.radiusLg,
        background: t.surfaceRaised,
        border: `1.5px solid ${ringOn ? accent : t.border}`,
        boxShadow: isOpp
          ? `0 0 0 2px ${t.danger}22, 0 8px 22px rgba(0,0,0,0.35)`
          : selected ? t.glow : `0 6px 14px rgba(0,0,0,0.25)`,
        padding: 8,
        cursor: onSelect ? 'pointer' : 'default',
        boxSizing: 'border-box',
        transition: 'box-shadow 140ms ease, border-color 140ms ease',
      }}>
      {/* side label tab */}
      <div style={{
        position: 'absolute', top: -10, left: 12,
        background: ringOn ? accent : t.surfaceSunken, color: ringOn ? '#fff' : t.textMute,
        fontFamily: t.fontBody, fontWeight: 700, fontSize: 9,
        letterSpacing: '0.12em', textTransform: 'uppercase',
        padding: '2px 8px', borderRadius: 999,
        boxShadow: '0 2px 6px rgba(0,0,0,0.35)',
      }}>{isOpp ? 'Opponent Active' : 'Your Active'}</div>

      <div style={{ display: 'flex', gap: 10 }}>
        <CardPlaceholder t={t} w={84} h={116} type={type} name={name} hp={maxHp} attached={0} active={!isOpp} />
        <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 4 }}>
              <span style={{
                fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 15,
                color: t.text, letterSpacing: '-0.01em',
                overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              }}>{name}</span>
              {status && <Pill t={t} tone="warn" style={{ padding: '1px 6px', fontSize: 9 }}>{status}</Pill>}
            </div>
            {/* HP large */}
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 4, marginTop: 4 }}>
              <span style={{ fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 24, color: t.text, lineHeight: 1 }}>{hp}</span>
              <span style={{ fontFamily: t.fontMono, fontSize: 11.5, color: t.textMute }}>/{maxHp}</span>
            </div>
            {/* HP bar */}
            <div style={{ height: 6, background: t.surfaceSunken, borderRadius: 999, marginTop: 4, overflow: 'hidden' }}>
              <div style={{
                width: `${pct}%`, height: '100%',
                background: pct > 50 ? t.ok : pct > 25 ? t.accent3 : t.danger,
                borderRadius: 999,
              }} />
            </div>
          </div>
          {/* attached energy */}
          <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap', marginTop: 6 }}>
            {attached.map((a, i) => (
              <EnergyPip key={i} t={t} type={a.type} count={a.count} />
            ))}
            {attackHint && (
              <Pill t={t} tone="default" style={{ padding: '2px 6px', fontSize: 9.5 }}>{attackHint}</Pill>
            )}
          </div>
        </div>
      </div>
    </button>
  );
}

// ─────────────────────────────────────────────────────────────
// Compact card — used for bench + opponent
// ─────────────────────────────────────────────────────────────
function CompactCard({ t, type, hp, maxHp, attached = 0, active = false, mini = false, name, bench = false, labelTone, hasAbility = false }) {
  const w = mini ? 44 : bench ? 56 : 68;
  const h = mini ? 60 : bench ? 78 : 92;
  const pct = maxHp ? (hp / maxHp) * 100 : 100;
  const hpColor = pct > 50 ? t.ok : pct > 25 ? t.accent3 : t.danger;
  return (
    <div style={{
      position: 'relative', width: w, height: h,
      borderRadius: t.radius - 2,
      background: `repeating-linear-gradient(135deg, ${stripeFor(type)[0]} 0px, ${stripeFor(type)[0]} 4px, ${stripeFor(type)[1]} 4px, ${stripeFor(type)[1]} 8px)`,
      boxShadow: active ? t.glow : t.shadowCard,
      border: active && labelTone ? `1.5px solid ${labelTone}` : 'none',
      overflow: 'hidden', flex: '0 0 auto',
    }}>
      {/* HP bar */}
      {hp != null && (
        <div style={{
          position: 'absolute', top: 4, left: 4, right: 4,
          height: 4, background: 'rgba(0,0,0,0.5)', borderRadius: 999, overflow: 'hidden',
        }}>
          <div style={{ width: `${pct}%`, height: '100%', background: hpColor }} />
        </div>
      )}
      {/* HP num */}
      {hp != null && !mini && (
        <div style={{
          position: 'absolute', top: 11, left: 4,
          background: 'rgba(0,0,0,0.55)',
          color: '#fff', fontFamily: t.fontMono, fontWeight: 700, fontSize: 9,
          padding: '1px 4px', borderRadius: 3, lineHeight: 1,
        }}>{hp}</div>
      )}
      {/* attached energy badge */}
      {attached > 0 && (
        <div style={{
          position: 'absolute', top: 4, right: 4,
          background: ENERGY_COLOR[type] || '#fff',
          color: '#fff', fontFamily: t.fontMono, fontWeight: 700, fontSize: 9,
          width: 14, height: 14, borderRadius: 999,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 0 0 1.5px rgba(0,0,0,0.45)',
        }}>{attached}</div>
      )}
      {/* ability indicator gem */}
      {hasAbility && (
        <div style={{
          position: 'absolute', top: 11, right: 4,
          width: 10, height: 10, borderRadius: 2,
          background: t.accent2,
          transform: 'rotate(45deg)',
          boxShadow: '0 0 0 1.5px rgba(0,0,0,0.45), 0 0 6px rgba(74,214,224,0.7)',
        }} />
      )}
      {/* card-art band */}
      <div style={{
        position: 'absolute', left: 4, right: 4,
        bottom: name ? 16 : 4,
        top: hp ? 22 : 4,
        background: 'rgba(0,0,0,0.35)',
        borderRadius: 3,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <span style={{
          fontFamily: t.fontMono, fontSize: mini ? 7 : 8, color: 'rgba(255,255,255,0.55)',
          textTransform: 'uppercase', letterSpacing: '0.1em',
        }}>art</span>
      </div>
      {/* name */}
      {name && !mini && (
        <div style={{
          position: 'absolute', left: 3, right: 3, bottom: 3,
          background: 'rgba(0,0,0,0.6)',
          color: '#fff', fontFamily: t.fontBody, fontWeight: 600, fontSize: 8.5,
          padding: '1px 3px', borderRadius: 2,
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', lineHeight: 1.15,
        }}>{name}</div>
      )}
    </div>
  );
}

function stripeFor(type) {
  const map = {
    fire:      ['#ff7a3d', '#c63a1a'],
    water:     ['#3fb6ff', '#1968b3'],
    grass:     ['#5fd16a', '#2a7a35'],
    lightning: ['#ffd445', '#caa01a'],
    psychic:   ['#cc7af6', '#6b29a0'],
    fighting:  ['#d4863a', '#7a4615'],
    dark:      ['#3a3a4a', '#15151c'],
    metal:     ['#bdc6d2', '#6b7480'],
    colorless: ['#e8e1cf', '#a89b78'],
  };
  return map[type] || map.colorless;
}

function EmptyBench({ t }) {
  return (
    <div style={{
      width: 56, height: 78,
      borderRadius: t.radius - 2,
      border: `1.5px dashed ${t.borderStrong}`,
      background: 'transparent',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: t.textMute,
    }}>
      <Icon name="plus" size={14} color={t.textMute} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Prize / deck / discard stack chip
// ─────────────────────────────────────────────────────────────
function Stack({ t, label, count, color, size = 'md' }) {
  const isSm = size === 'sm';
  return (
    <button style={{
      display: 'flex', alignItems: 'center', gap: 6,
      padding: isSm ? '3px 7px' : '6px 9px',
      background: t.surfaceSunken, border: `1px solid ${t.border}`,
      borderRadius: 8, cursor: 'pointer', color: t.text,
    }}>
      <div style={{ position: 'relative', width: isSm ? 14 : 16, height: isSm ? 18 : 22, flexShrink: 0 }}>
        <div style={{
          position: 'absolute', inset: 0, borderRadius: 2,
          background: color || t.accent2, opacity: 0.45,
          transform: 'translate(2px, 2px)',
        }} />
        <div style={{
          position: 'absolute', inset: 0, borderRadius: 2,
          background: color || t.accent2,
        }} />
      </div>
      <div style={{ textAlign: 'left' }}>
        <div style={{ fontFamily: t.fontMono, fontWeight: 700, fontSize: isSm ? 11 : 13, color: t.text, lineHeight: 1 }}>{count}</div>
        <div style={{ fontFamily: t.fontBody, fontSize: isSm ? 8.5 : 9, color: t.textMute, marginTop: 1, letterSpacing: '0.04em', textTransform: 'uppercase' }}>{label}</div>
      </div>
    </button>
  );
}

// ─────────────────────────────────────────────────────────────
// Turn banner with slot counts
// ─────────────────────────────────────────────────────────────
function TurnBanner({ t }) {
  return (
    <div style={{
      margin: '6px 12px 0',
      padding: '8px 12px',
      background: t.name === 'Paper' ? '#fff8e7' : 'rgba(255, 214, 10, 0.10)',
      border: `1px solid ${t.accent3}`,
      borderRadius: t.radius,
      display: 'flex', alignItems: 'center', gap: 10,
    }}>
      <div style={{
        width: 26, height: 26, borderRadius: 999,
        background: t.accent3, color: t.name === 'Paper' ? '#1f1408' : '#1f1408',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 11,
      }}>T4</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 12.5, color: t.text, lineHeight: 1.1 }}>Your turn</div>
        <div style={{ fontFamily: t.fontBody, fontSize: 10.5, color: t.textDim, marginTop: 1 }}>
          <SlotChip label="E" used={0} max={1} t={t} /> <SlotChip label="Sup" used={1} max={1} t={t} /> <SlotChip label="Item" used={0} max="∞" t={t} />
        </div>
      </div>
    </div>
  );
}

function SlotChip({ label, used, max, t }) {
  const exhausted = max !== '∞' && used >= max;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 3,
      fontFamily: t.fontMono, fontSize: 10, fontWeight: 700,
      color: exhausted ? t.textMute : t.text,
      marginRight: 5,
    }}>
      {label} <span style={{ color: exhausted ? t.danger : t.ok }}>{used}/{max}</span>
    </span>
  );
}

// ─────────────────────────────────────────────────────────────
// Hand drawer — fanned by default, swipe up to expand
// ─────────────────────────────────────────────────────────────
function HandDrawer({ t, cards, expanded, onToggle, layout, selectedHand, setSelectedHand }) {
  // Tweaks-panel `layout` is the source of truth; local `expanded` flips it
  // for the session via the in-drawer Fan/Grid button.
  const isGrid = expanded ? (layout !== 'grid') : (layout === 'grid');
  return (
    <div style={{
      marginTop: 6,
      background: t.surface,
      borderTop: `1px solid ${t.borderStrong}`,
      borderTopLeftRadius: t.radiusLg, borderTopRightRadius: t.radiusLg,
      padding: '6px 8px 4px',
      position: 'relative',
    }}>
      {/* grip + label */}
      <button onClick={onToggle} style={{
        display: 'flex', alignItems: 'center', gap: 8,
        width: '100%', background: 'transparent', border: 'none', cursor: 'pointer',
        padding: '2px 6px 4px',
      }}>
        <div style={{
          flex: 1, height: 4, borderRadius: 999, background: t.borderStrong,
          maxWidth: 40, margin: '0 auto',
        }} />
      </button>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 4px 4px' }}>
        <div style={{
          fontFamily: t.fontBody, fontWeight: 700, fontSize: 11, color: t.textDim,
          letterSpacing: '0.08em', textTransform: 'uppercase',
        }}>Your hand · {cards.length}</div>
        <div style={{ display: 'flex', gap: 4 }}>
          <button onClick={onToggle} style={{
            background: 'transparent', border: `1px solid ${t.border}`, color: t.textDim,
            borderRadius: 999, padding: '2px 8px',
            fontFamily: t.fontBody, fontWeight: 600, fontSize: 10, cursor: 'pointer',
          }}>{isGrid ? 'Fan' : 'Grid'}</button>
        </div>
      </div>

      {/* cards row */}
      {isGrid ? (
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6,
          padding: '4px 4px 6px',
          maxHeight: 230, overflowY: 'auto', scrollbarWidth: 'thin',
        }}>
          {cards.map((c, i) => (
            <button key={i} onClick={() => setSelectedHand(i)} style={{
              background: 'transparent', border: 'none', padding: 0, cursor: 'pointer',
              display: 'flex', justifyContent: 'center',
            }}>
              <CardPlaceholder t={t} w={68} h={94} {...c} active={selectedHand === i} />
            </button>
          ))}
        </div>
      ) : (
        <FannedHand t={t} cards={cards} selectedHand={selectedHand} setSelectedHand={setSelectedHand} />
      )}
    </div>
  );
}

function FannedHand({ t, cards, selectedHand, setSelectedHand }) {
  const n = cards.length;
  // Render cards offset horizontally, slight rotation
  return (
    <div style={{
      position: 'relative',
      height: 132,
      margin: '0 4px 4px',
      overflow: 'visible',
    }}>
      {cards.map((c, i) => {
        const center = (n - 1) / 2;
        const offset = i - center;
        const isSelected = selectedHand === i;
        const slotWidth = 360 / n;
        const left = i * slotWidth - (slotWidth * 0.08);
        const rot = offset * 3.5;
        const ty = Math.abs(offset) * 1.5 + (isSelected ? -16 : 0);
        return (
          <button
            key={i}
            onClick={() => setSelectedHand(isSelected ? null : i)}
            style={{
              position: 'absolute',
              left, bottom: 4,
              transform: `translateY(${ty}px) rotate(${rot}deg)`,
              transformOrigin: 'bottom center',
              transition: 'transform 160ms cubic-bezier(.2,.7,.3,1)',
              background: 'transparent', border: 'none', padding: 0,
              cursor: 'pointer', zIndex: isSelected ? 50 : i,
            }}
          >
            <CardPlaceholder
              t={t} w={70} h={98}
              type={c.type} name={c.name} hp={c.hp || 0}
              attached={0}
              label={c.label}
              active={isSelected}
              style={{ boxShadow: isSelected ? t.glow : t.shadowCard }}
            />
          </button>
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Action bar — big primary Attack, secondary actions
// ─────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────
// Action bar — context-aware:
//   selectedCard.location === 'active' → attacks + ability + retreat
//   selectedCard.location === 'bench'  → ability (if any) + promote
// Always shows End Turn at the right.
// ─────────────────────────────────────────────────────────────
function ActionBar({ t, setScreen, selectedCard, onClearSelection }) {
  const isBench = selectedCard?.location === 'bench';
  const attacks = !isBench ? (selectedCard?.attacks || []) : [];
  const ability = selectedCard?.ability;
  return (
    <div style={{
      background: t.surfaceRaised,
      borderTop: `1px solid ${t.borderStrong}`,
      paddingBottom: `calc(20px + env(safe-area-inset-bottom, 0px))`,
    }}>
      {/* selection header — what card the buttons below act on */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        padding: '6px 12px 4px',
        borderBottom: `1px solid ${t.border}`,
      }}>
        <div style={{
          fontFamily: t.fontBody, fontSize: 9, fontWeight: 700,
          color: isBench ? t.accent2 : t.accent,
          textTransform: 'uppercase', letterSpacing: '0.12em',
        }}>{isBench ? 'Bench' : 'Active'}</div>
        <div style={{
          fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 13,
          color: t.text, letterSpacing: '-0.01em',
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
          flex: 1, minWidth: 0,
        }}>{selectedCard?.name || '—'}</div>
        {isBench && (
          <button onClick={onClearSelection} style={{
            background: 'transparent', border: `1px solid ${t.border}`,
            color: t.textDim, borderRadius: 999, padding: '2px 9px',
            fontFamily: t.fontBody, fontWeight: 600, fontSize: 10,
            cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 4,
          }}>
            <Icon name="arrowLeft" size={10} color={t.textDim} />
            Active
          </button>
        )}
      </div>

      {/* action buttons */}
      <div style={{
        padding: '8px 12px 8px',
        display: 'flex', gap: 6, alignItems: 'stretch',
      }}>
        {!isBench && attacks.length > 0 && (
          <ActionBtn t={t} variant="primary"
            label={attacks[0].name} damage={attacks[0].damage} cost={attacks[0].cost}
            usable={attacks[0].costMet >= attacks[0].costTotal}
            kind="attack" />
        )}
        {!isBench && ability && (
          <IconAction t={t} icon="sparkle" label="Ability" tone="ability"
            used={ability.used} ariaLabel={ability.name} />
        )}

        {isBench && ability && (
          <ActionBtn t={t} variant="primary"
            label={ability.name} kind="ability" used={ability.used} />
        )}
        {isBench && !ability && (
          <div style={{
            flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            background: t.surfaceSunken, border: `1px dashed ${t.border}`,
            borderRadius: t.radius, padding: '10px',
            color: t.textMute,
            fontFamily: t.fontBody, fontSize: 11.5, fontWeight: 500,
          }}>
            <Icon name="info" size={12} color={t.textMute} />
            No usable ability
          </div>
        )}

        {/* Retreat / Promote — context-dependent secondary */}
        {!isBench ? (
          <IconAction t={t} icon="retreat" label="Retreat" />
        ) : (
          <IconAction t={t} icon="arrow" label="Promote" />
        )}

        {/* End Turn — always */}
        <IconAction t={t} icon="check" label="End turn" tone="accent3" onClick={() => setScreen('home')} />
      </div>
    </div>
  );
}

function ActionBtn({ t, variant = 'primary', label, damage, cost, usable = true, kind, used = false }) {
  const isPrimary = variant === 'primary';
  const isAbility = kind === 'ability';
  const baseBg = isPrimary
    ? (isAbility ? t.accent2 : t.accent)
    : variant === 'ability'
      ? t.surfaceSunken
      : t.surface;
  const fg = isPrimary ? (isAbility ? '#0a1116' : t.accentInk) : t.text;
  const accentBorder = isAbility ? t.accent2 : t.accent;
  return (
    <button disabled={!usable || used} style={{
      flex: variant === 'primary' ? 1 : '0 1 auto',
      minWidth: variant === 'primary' ? 0 : 96,
      background: baseBg, color: fg,
      border: isPrimary ? 'none' : `1px solid ${variant === 'ability' ? accentBorder : t.border}`,
      borderRadius: t.radius, padding: '10px 12px',
      cursor: usable && !used ? 'pointer' : 'not-allowed',
      opacity: usable && !used ? 1 : 0.55,
      display: 'flex', flexDirection: 'column', alignItems: 'flex-start',
      boxShadow: isPrimary && t.name === 'Arcade'
        ? `0 0 0 1px rgba(255,255,255,0.15), 0 4px 14px ${isAbility ? 'rgba(0,224,255,0.45)' : 'rgba(255,45,142,0.55)'}`
        : isPrimary ? '0 2px 0 rgba(0,0,0,0.18)' : 'none',
      minHeight: 56, textAlign: 'left',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, width: '100%', minWidth: 0 }}>
        <Icon name={isAbility ? 'sparkle' : 'swords'} size={13} color={fg} />
        <span style={{
          fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 13.5, letterSpacing: '-0.01em',
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1, minWidth: 0,
        }}>{label}</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4 }}>
        {damage != null && (
          <span style={{
            fontFamily: t.fontMono, fontWeight: 700, fontSize: 11.5,
            background: 'rgba(0,0,0,0.25)', color: '#fff',
            padding: '1px 5px', borderRadius: 4,
          }}>{damage}</span>
        )}
        {cost && (
          <span style={{ display: 'flex', gap: 2 }}>
            {cost.map((tp, i) => (
              <span key={i} style={{
                width: 9, height: 9, borderRadius: 999,
                background: ENERGY_COLOR[tp],
                boxShadow: '0 0 0 1px rgba(0,0,0,0.45)',
              }} />
            ))}
          </span>
        )}
        {isAbility && (
          <span style={{
            fontFamily: t.fontMono, fontSize: 9.5, fontWeight: 600,
            color: isPrimary ? 'rgba(0,0,0,0.55)' : t.textMute,
            textTransform: 'uppercase', letterSpacing: '0.08em',
          }}>{used ? 'used' : 'Ability'}</span>
        )}
      </div>
    </button>
  );
}

function IconAction({ t, icon, label, tone, onClick, used = false, ariaLabel }) {
  const isAbility = tone === 'ability';
  const isAccent = tone === 'accent3';
  const color = isAccent ? t.accent3 : isAbility ? t.accent2 : t.text;
  const border = isAccent ? t.accent3 : isAbility ? t.accent2 : t.border;
  return (
    <button onClick={onClick} disabled={used} aria-label={ariaLabel || label} style={{
      width: 60, background: isAbility ? `${t.accent2}1a` : t.surfaceSunken, color,
      border: `1px solid ${border}`, borderRadius: t.radius,
      cursor: used ? 'not-allowed' : 'pointer',
      opacity: used ? 0.45 : 1,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2,
      minHeight: 56,
    }}>
      <Icon name={icon} size={18} color={color} />
      <span style={{
        fontFamily: t.fontBody, fontWeight: 700, fontSize: 9.5,
        color: isAccent ? t.accent3 : isAbility ? t.accent2 : t.textDim,
        textTransform: isAbility ? 'uppercase' : 'none',
        letterSpacing: isAbility ? '0.06em' : '0.01em',
      }}>{label}</span>
    </button>
  );
}

Object.assign(window, {
  GameScreen, BigActive, CompactCard, EmptyBench, Stack, TurnBanner, SlotChip,
  HandDrawer, FannedHand, ActionBar,
});
