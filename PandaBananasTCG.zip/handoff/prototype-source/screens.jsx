// All five mobile screens for PandaBananasTCG redesign.
// Each screen takes (t, density, layout, screen, setScreen, sync).
// Screens are 390-wide; the iOS frame clips the top notch and bottom indicator.

// ─────────────────────────────────────────────────────────────
// Shared shell: top bar
// ─────────────────────────────────────────────────────────────
function TopBar({ t, title, left, right, subtitle }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: '14px 16px 10px',
      borderBottom: `1px solid ${t.border}`,
      background: t.surface,
    }}>
      <div style={{ width: 36 }}>{left}</div>
      <div style={{ flex: 1, textAlign: 'center', minWidth: 0 }}>
        <div style={{
          fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 17,
          color: t.text, letterSpacing: '-0.01em',
          whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
        }}>{title}</div>
        {subtitle && <div style={{
          fontFamily: t.fontBody, fontSize: 10.5, color: t.textMute,
          marginTop: 1, letterSpacing: '0.02em',
        }}>{subtitle}</div>}
      </div>
      <div style={{ width: 36, display: 'flex', justifyContent: 'flex-end' }}>{right}</div>
    </div>
  );
}

function IconBtn({ t, icon, onClick, ariaLabel }) {
  return (
    <button onClick={onClick} aria-label={ariaLabel} style={{
      width: 36, height: 36, borderRadius: t.radiusFull,
      background: t.surfaceRaised, color: t.text,
      border: `1px solid ${t.border}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      cursor: 'pointer',
    }}>
      <Icon name={icon} size={18} color={t.text} />
    </button>
  );
}

// ─────────────────────────────────────────────────────────────
// Bottom nav (Home / Build / Doctor / Replays)
// ─────────────────────────────────────────────────────────────
function BottomNav({ t, screen, setScreen }) {
  const items = [
    { id: 'home', icon: 'home', label: 'Home' },
    { id: 'pregame', icon: 'play', label: 'Play' },
    { id: 'builder', icon: 'cards', label: 'Build' },
    { id: 'doctor', icon: 'stethoscope', label: 'Doctor' },
    { id: 'game', icon: 'swords', label: 'Match' },
  ];
  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, bottom: 0,
      paddingBottom: 'env(safe-area-inset-bottom, 0px)',
      background: t.surfaceSolid.includes('linear') ? t.surfaceSolid : t.surface,
      borderTop: `1px solid ${t.border}`,
      backdropFilter: 'blur(10px)',
      zIndex: 5,
    }}>
      <div style={{
        display: 'grid', gridTemplateColumns: `repeat(${items.length}, 1fr)`,
        padding: '6px 4px 18px',
      }}>
        {items.map(it => {
          const on = screen === it.id || (screen === 'game' && it.id === 'game');
          return (
            <button key={it.id} onClick={() => setScreen(it.id)} style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
              padding: '6px 4px', background: 'transparent', border: 'none', cursor: 'pointer',
              color: on ? t.accent : t.textMute,
              fontFamily: t.fontBody, fontWeight: 600, fontSize: 10,
              letterSpacing: '0.02em',
            }}>
              <div style={{
                width: 32, height: 24, borderRadius: 8,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: on ? (t.name === 'Arcade' ? 'rgba(255,45,142,0.18)' : 'rgba(123,92,255,0.15)') : 'transparent',
                transition: 'background 120ms ease',
              }}>
                <Icon name={it.icon} size={18} color={on ? t.accent : t.textMute} strokeWidth={on ? 2.2 : 1.8} />
              </div>
              <span>{it.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// HOME
// ─────────────────────────────────────────────────────────────
function HomeScreen({ t, setScreen, density }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: t.bg, color: t.text, paddingBottom: 64 }}>
      <div style={{ padding: '16px 18px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Wordmark t={t} size={18} />
        <IconBtn t={t} icon="settings" ariaLabel="Settings" />
      </div>

      {/* dataset chip */}
      <div style={{ padding: '0 18px', display: 'flex', gap: 6, flexWrap: 'wrap' }}>
        <Pill t={t} tone="default" icon={<Icon name="sparkle" size={11} color={t.accent3} />}>Standard · dataset 2026-05</Pill>
        <Pill t={t} tone="default">2,776 cards</Pill>
      </div>

      {/* Hero tile: Play */}
      <div style={{ padding: '18px 18px 12px' }}>
        <button
          onClick={() => setScreen('pregame')}
          style={{
            width: '100%', textAlign: 'left', cursor: 'pointer', border: 'none',
            padding: 0,
            background: 'transparent',
          }}
        >
          <div style={{
            position: 'relative', overflow: 'hidden',
            borderRadius: t.radiusLg,
            padding: '22px 20px',
            background: t.name === 'Paper'
              ? `linear-gradient(135deg, ${t.accent} 0%, #d96b3e 100%)`
              : t.name === 'Arcade'
                ? 'linear-gradient(135deg, #ff2d8e 0%, #7b3cff 100%)'
                : 'linear-gradient(135deg, #7b5cff 0%, #4ad6e0 100%)',
            color: '#fff',
            boxShadow: t.shadowFloat,
          }}>
            {/* decorative cards stack */}
            <div style={{ position: 'absolute', right: -16, top: -8, opacity: 0.85, transform: 'rotate(8deg)' }}>
              <div style={{ display: 'flex', gap: -10 }}>
                <CardPlaceholder t={t} w={56} h={80} faceDown name="" style={{ marginRight: -20, transform: 'rotate(-10deg)' }} />
                <CardPlaceholder t={t} w={56} h={80} faceDown name="" style={{ transform: 'rotate(6deg)' }} />
              </div>
            </div>
            <div style={{ position: 'relative', maxWidth: '60%' }}>
              <div style={{ fontFamily: t.fontBody, fontSize: 11, letterSpacing: '0.12em', textTransform: 'uppercase', opacity: 0.85 }}>Quick Play</div>
              <div style={{ fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 28, lineHeight: 1.05, marginTop: 2, letterSpacing: '-0.02em' }}>Start a match</div>
              <div style={{ fontFamily: t.fontBody, fontSize: 12.5, marginTop: 8, opacity: 0.9, lineHeight: 1.4 }}>
                vs CPU or pass-and-play. Preset decks, your imports, or build one.
              </div>
              <div style={{ marginTop: 14, display: 'inline-flex', alignItems: 'center', gap: 6,
                background: 'rgba(0,0,0,0.25)', borderRadius: 999, padding: '6px 12px',
                fontFamily: t.fontBody, fontWeight: 600, fontSize: 12,
              }}>
                <Icon name="play" size={11} color="#fff" /> Tap to start
              </div>
            </div>
          </div>
        </button>
      </div>

      {/* Secondary tiles: Doctor + Build */}
      <div style={{ padding: '0 18px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {[
          { id: 'doctor', icon: 'stethoscope', title: 'Deck Doctor', desc: 'Analyze vs the meta', tone: t.accent2 },
          { id: 'builder', icon: 'cards', title: 'Deck Builder', desc: 'Build from the pool', tone: t.accent3 },
        ].map(tile => (
          <button key={tile.id} onClick={() => setScreen(tile.id)} style={{
            textAlign: 'left', cursor: 'pointer', padding: '14px 14px 12px',
            background: t.surface, border: `1px solid ${t.border}`,
            borderRadius: t.radiusLg, color: t.text,
            display: 'flex', flexDirection: 'column', gap: 8,
            minHeight: 110,
          }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: tile.tone, color: '#fff',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Icon name={tile.icon} size={18} color={t.name === 'Paper' ? '#fff' : '#fff'} />
            </div>
            <div style={{ fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 16, letterSpacing: '-0.01em' }}>{tile.title}</div>
            <div style={{ fontFamily: t.fontBody, fontSize: 11.5, color: t.textDim, lineHeight: 1.35 }}>{tile.desc}</div>
          </button>
        ))}
      </div>

      {/* Recent activity */}
      <div style={{ padding: '18px 18px 0', flex: 1 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
          <div style={{ fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 13, letterSpacing: '0.06em', textTransform: 'uppercase', color: t.textDim }}>Recent matches</div>
          <button style={{ background: 'transparent', border: 'none', color: t.accent, fontFamily: t.fontBody, fontWeight: 600, fontSize: 11.5, cursor: 'pointer' }}>See all</button>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {[
            { result: 'W', deck: 'Charizard ex', vs: 'Gardevoir ex', turns: 11, ago: '2h' },
            { result: 'L', deck: 'Lugia VSTAR', vs: 'Roaring Moon', turns: 14, ago: '1d' },
            { result: 'W', deck: 'Lost Zone Box', vs: 'Snorlax Stall', turns: 18, ago: '3d' },
          ].map((r, i) => (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 10,
              padding: '10px 12px',
              background: t.surface, border: `1px solid ${t.border}`,
              borderRadius: t.radius,
            }}>
              <div style={{
                width: 28, height: 28, borderRadius: 8,
                background: r.result === 'W' ? t.ok : t.danger,
                color: '#fff',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 13,
              }}>{r.result}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: t.fontBody, fontWeight: 600, fontSize: 13, color: t.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.deck}</div>
                <div style={{ fontFamily: t.fontBody, fontSize: 10.5, color: t.textMute, marginTop: 1 }}>vs {r.vs} · {r.turns} turns</div>
              </div>
              <div style={{ fontFamily: t.fontMono, fontSize: 10.5, color: t.textMute }}>{r.ago}</div>
            </div>
          ))}
        </div>
      </div>

      <BottomNav t={t} screen="home" setScreen={setScreen} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// PREGAME
// ─────────────────────────────────────────────────────────────
function PreGameScreen({ t, setScreen, density }) {
  const [mode, setMode] = React.useState('vsCPU');
  const [openHands, setOpenHands] = React.useState(false);
  const [myDeck, setMyDeck] = React.useState('charizard');
  const [oppDeck, setOppDeck] = React.useState('random');

  const decks = [
    { id: 'charizard', name: 'Charizard ex', types: ['fire', 'colorless'], cards: 60, tag: 'Preset' },
    { id: 'gardevoir', name: 'Gardevoir ex', types: ['psychic'], cards: 60, tag: 'Preset' },
    { id: 'lugia', name: 'Lugia VSTAR', types: ['colorless'], cards: 60, tag: 'Preset' },
    { id: 'lostbox', name: 'Lost Zone Box', types: ['water', 'grass'], cards: 60, tag: 'Imported' },
    { id: 'random', name: 'Random preset', types: ['colorless'], cards: 60, tag: 'CPU' },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: t.bg, color: t.text }}>
      <TopBar
        t={t} title="Start a game" subtitle="Pick decks for both sides"
        left={<IconBtn t={t} icon="arrowLeft" onClick={() => setScreen('home')} ariaLabel="Back" />}
        right={<IconBtn t={t} icon="info" ariaLabel="Help" />}
      />

      <div style={{ flex: 1, overflow: 'auto', padding: '14px 16px 140px' }}>
        {/* Mode toggle */}
        <div style={{
          display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 0,
          padding: 4, background: t.surfaceSunken, borderRadius: t.radius,
          border: `1px solid ${t.border}`,
        }}>
          {[{ id: 'vsCPU', label: 'vs CPU', icon: 'target' }, { id: 'local', label: 'Hotseat', icon: 'hand' }].map(m => (
            <button key={m.id} onClick={() => setMode(m.id)} style={{
              padding: '10px 8px', borderRadius: t.radius - 2,
              background: mode === m.id ? t.surfaceRaised : 'transparent',
              color: mode === m.id ? t.text : t.textMute,
              border: 'none', cursor: 'pointer',
              fontFamily: t.fontBody, fontWeight: 600, fontSize: 13,
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
              boxShadow: mode === m.id && t.name === 'Paper' ? '0 1px 3px rgba(0,0,0,0.06)' : 'none',
            }}>
              <Icon name={m.icon} size={14} color={mode === m.id ? t.accent : t.textMute} />
              {m.label}
            </button>
          ))}
        </div>

        {/* You / Opponent cards */}
        <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 10 }}>
          <DeckSlot t={t} side="you" label={mode === 'local' ? 'Player 1' : 'You'} deck={decks.find(d => d.id === myDeck)} onTap={() => {}} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ flex: 1, height: 1, background: t.border }} />
            <div style={{
              fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 16,
              color: t.textMute, letterSpacing: '0.08em',
            }}>VS</div>
            <div style={{ flex: 1, height: 1, background: t.border }} />
          </div>
          <DeckSlot t={t} side="opp" label={mode === 'local' ? 'Player 2' : 'CPU'} deck={decks.find(d => d.id === oppDeck)} onTap={() => {}} />
        </div>

        {/* Options */}
        <div style={{ marginTop: 18 }}>
          <div style={{ fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 12, letterSpacing: '0.06em', textTransform: 'uppercase', color: t.textDim, marginBottom: 8 }}>Options</div>
          <Surface t={t} style={{ padding: '4px 14px' }}>
            <ToggleRow t={t} label="Open hands" sub="Reveal CPU cards (for learning)" value={openHands} onChange={setOpenHands} disabled={mode === 'local'} />
            <Divider t={t} />
            <ToggleRow t={t} label="Auto-save replays" sub="Persist match for review" value={true} onChange={() => {}} />
          </Surface>
        </div>

        {/* Quick actions */}
        <div style={{ marginTop: 18, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          <Btn t={t} variant="outline" icon={<Icon name="cards" size={15} />} onClick={() => setScreen('builder')}>Build deck</Btn>
          <Btn t={t} variant="outline" icon={<Icon name="stethoscope" size={15} />} onClick={() => setScreen('doctor')}>Doctor</Btn>
        </div>
      </div>

      {/* Fixed start button */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 78,
        padding: '12px 16px',
        background: `linear-gradient(180deg, transparent 0%, ${t.bgSolid} 40%)`,
      }}>
        <Btn t={t} variant="primary" size="lg" fullWidth icon={<Icon name="play" size={14} color={t.accentInk} />} onClick={() => setScreen('game')}>
          Start match
        </Btn>
      </div>

      <BottomNav t={t} screen="pregame" setScreen={setScreen} />
    </div>
  );
}

function DeckSlot({ t, side, label, deck }) {
  if (!deck) return null;
  return (
    <button style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '12px 12px',
      background: t.surface, border: `1px solid ${side === 'you' ? t.accent : t.border}`,
      borderLeft: `4px solid ${side === 'you' ? t.accent : t.accent2}`,
      borderRadius: t.radiusLg, cursor: 'pointer', color: t.text,
      width: '100%', textAlign: 'left',
    }}>
      <CardPlaceholder t={t} w={50} h={70} type={deck.types[0]} name={deck.name} hp={null} attached={0} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: t.fontBody, fontSize: 10.5, color: t.textMute, textTransform: 'uppercase', letterSpacing: '0.08em' }}>{label}</div>
        <div style={{ fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 17, color: t.text, marginTop: 2, lineHeight: 1.1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{deck.name}</div>
        <div style={{ display: 'flex', gap: 5, marginTop: 6, alignItems: 'center' }}>
          {deck.types.map(typ => <TypeDot key={typ} type={typ} size={10} />)}
          <span style={{ fontFamily: t.fontMono, fontSize: 10, color: t.textMute }}>{deck.cards} cards</span>
          <Pill t={t} tone={deck.tag === 'Imported' ? 'accent2' : 'default'} style={{ padding: '1px 6px', fontSize: 9.5 }}>{deck.tag}</Pill>
        </div>
      </div>
      <Icon name="chevron" size={16} color={t.textMute} />
    </button>
  );
}

function ToggleRow({ t, label, sub, value, onChange, disabled }) {
  return (
    <label style={{
      display: 'flex', alignItems: 'center', gap: 12,
      padding: '12px 0', cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: t.fontBody, fontWeight: 600, fontSize: 13.5, color: t.text }}>{label}</div>
        {sub && <div style={{ fontFamily: t.fontBody, fontSize: 11, color: t.textMute, marginTop: 1 }}>{sub}</div>}
      </div>
      <div onClick={() => !disabled && onChange(!value)} style={{
        width: 42, height: 26, borderRadius: 999,
        background: value ? t.accent : t.surfaceSunken,
        border: `1px solid ${value ? t.accent : t.borderStrong}`,
        position: 'relative', transition: 'background 120ms ease',
        flex: '0 0 auto',
      }}>
        <div style={{
          position: 'absolute', top: 2, left: value ? 18 : 2,
          width: 20, height: 20, borderRadius: 999,
          background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.2)',
          transition: 'left 140ms ease',
        }} />
      </div>
    </label>
  );
}

function Divider({ t }) {
  return <div style={{ height: 1, background: t.border, margin: '0 -14px' }} />;
}

// ─────────────────────────────────────────────────────────────
// DECK BUILDER
// ─────────────────────────────────────────────────────────────
function BuilderScreen({ t, setScreen, density }) {
  const [tab, setTab] = React.useState('pokemon');
  const tabs = [
    { id: 'pokemon', label: 'Pokémon', count: 14 },
    { id: 'trainer', label: 'Trainers', count: 32 },
    { id: 'energy', label: 'Energy', count: 14 },
  ];
  const pool = [
    { name: 'Charizard ex', type: 'fire', hp: 330, qty: 2, max: 4, tag: 'Stage 2' },
    { name: 'Charmeleon', type: 'fire', hp: 110, qty: 2, max: 4, tag: 'Stage 1' },
    { name: 'Charmander', type: 'fire', hp: 70, qty: 4, max: 4, tag: 'Basic' },
    { name: 'Pidgeot ex', type: 'colorless', hp: 280, qty: 2, max: 4, tag: 'Stage 2' },
    { name: 'Pidgeotto', type: 'colorless', hp: 90, qty: 2, max: 4, tag: 'Stage 1' },
    { name: 'Pidgey', type: 'colorless', hp: 50, qty: 2, max: 4, tag: 'Basic' },
  ];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: t.bg, color: t.text }}>
      <TopBar
        t={t}
        title="Deck Builder"
        subtitle="Charizard ex · 46/60"
        left={<IconBtn t={t} icon="arrowLeft" onClick={() => setScreen('home')} ariaLabel="Back" />}
        right={<IconBtn t={t} icon="check" ariaLabel="Save" />}
      />

      {/* Search + filter */}
      <div style={{ padding: '12px 16px 8px', display: 'flex', gap: 8 }}>
        <div style={{
          flex: 1, display: 'flex', alignItems: 'center', gap: 8,
          background: t.surfaceSunken, border: `1px solid ${t.border}`,
          borderRadius: t.radius, padding: '0 12px', height: 38,
        }}>
          <Icon name="search" size={14} color={t.textMute} />
          <span style={{ fontFamily: t.fontBody, fontSize: 13, color: t.textMute, flex: 1 }}>Search cards…</span>
        </div>
        <button style={{
          width: 38, height: 38, borderRadius: t.radius,
          background: t.surfaceRaised, border: `1px solid ${t.border}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer',
        }}>
          <Icon name="filter" size={16} color={t.text} />
        </button>
      </div>

      {/* Type filters */}
      <div style={{ padding: '0 16px 8px', display: 'flex', gap: 6, overflowX: 'auto', scrollbarWidth: 'none' }}>
        {['fire', 'water', 'grass', 'lightning', 'psychic', 'fighting', 'dark', 'metal', 'colorless'].map(typ => (
          <button key={typ} style={{
            display: 'inline-flex', alignItems: 'center', gap: 4,
            background: typ === 'fire' ? t.accent : t.surfaceSunken,
            color: typ === 'fire' ? t.accentInk : t.textDim,
            border: `1px solid ${typ === 'fire' ? t.accent : t.border}`,
            borderRadius: 999, padding: '5px 10px',
            fontFamily: t.fontBody, fontWeight: 600, fontSize: 11.5,
            cursor: 'pointer', flexShrink: 0,
          }}>
            <TypeDot type={typ} size={9} />
            {typ.charAt(0).toUpperCase() + typ.slice(1)}
          </button>
        ))}
      </div>

      {/* Tabs */}
      <div style={{
        display: 'flex', borderBottom: `1px solid ${t.border}`, padding: '0 16px',
      }}>
        {tabs.map(tb => (
          <button key={tb.id} onClick={() => setTab(tb.id)} style={{
            flex: 1, padding: '10px 0', background: 'transparent', border: 'none', cursor: 'pointer',
            color: tab === tb.id ? t.text : t.textMute,
            fontFamily: t.fontBody, fontWeight: 600, fontSize: 12.5,
            borderBottom: `2px solid ${tab === tb.id ? t.accent : 'transparent'}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          }}>
            {tb.label}
            <span style={{
              fontFamily: t.fontMono, fontSize: 10,
              background: t.surfaceSunken, color: t.textMute,
              padding: '1px 5px', borderRadius: 999,
            }}>{tb.count}</span>
          </button>
        ))}
      </div>

      {/* Pool list */}
      <div style={{ flex: 1, overflow: 'auto', padding: '8px 16px 130px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {pool.map((c, i) => (
          <div key={i} style={{
            display: 'flex', alignItems: 'center', gap: 12,
            padding: 10,
            background: t.surface, border: `1px solid ${t.border}`,
            borderRadius: t.radiusLg,
          }}>
            <CardPlaceholder t={t} w={48} h={66} type={c.type} name={c.name} hp={c.hp} attached={0} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: t.fontBody, fontWeight: 600, fontSize: 13.5, color: t.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.name}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4, flexWrap: 'wrap' }}>
                <TypeDot type={c.type} size={9} />
                <span style={{ fontFamily: t.fontMono, fontSize: 10, color: t.textMute }}>HP {c.hp}</span>
                <Pill t={t} style={{ padding: '1px 6px', fontSize: 9.5 }}>{c.tag}</Pill>
              </div>
            </div>
            <Stepper t={t} value={c.qty} max={c.max} />
          </div>
        ))}
      </div>

      {/* Deck summary bar */}
      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 78,
        padding: '10px 16px',
        background: t.surfaceRaised,
        borderTop: `1px solid ${t.borderStrong}`,
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        {/* count */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
            <span style={{ fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 22, color: t.text, lineHeight: 1 }}>46</span>
            <span style={{ fontFamily: t.fontMono, fontSize: 12, color: t.textMute }}>/ 60</span>
          </div>
          {/* progress bar */}
          <div style={{ height: 4, background: t.surfaceSunken, borderRadius: 999, marginTop: 4, overflow: 'hidden' }}>
            <div style={{ width: '76.6%', height: '100%', background: t.accent }} />
          </div>
          <div style={{ display: 'flex', gap: 4, marginTop: 6 }}>
            <MiniBreakdown t={t} label="P" color={t.accent} count={14} />
            <MiniBreakdown t={t} label="T" color={t.accent2} count={32} />
            <MiniBreakdown t={t} label="E" color={t.accent3} count={14} />
          </div>
        </div>
        <Btn t={t} variant="primary" icon={<Icon name="check" size={14} color={t.accentInk} />}>Save</Btn>
      </div>

      <BottomNav t={t} screen="builder" setScreen={setScreen} />
    </div>
  );
}

function MiniBreakdown({ t, label, color, count }) {
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      background: t.surfaceSunken, borderRadius: 6, padding: '2px 6px',
    }}>
      <span style={{ width: 6, height: 6, borderRadius: 999, background: color }} />
      <span style={{ fontFamily: t.fontMono, fontSize: 10, color: t.textDim }}>{label} {count}</span>
    </div>
  );
}

function Stepper({ t, value, max }) {
  const isMax = value >= max;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
      <button style={{
        width: 32, height: 32, borderRadius: 999,
        background: t.surfaceSunken, border: `1px solid ${t.border}`,
        color: t.text, cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}><Icon name="minus" size={14} color={t.text} /></button>
      <div style={{
        minWidth: 28, textAlign: 'center',
        fontFamily: t.fontMono, fontWeight: 700, fontSize: 14, color: t.text,
      }}>{value}</div>
      <button style={{
        width: 32, height: 32, borderRadius: 999,
        background: isMax ? t.surfaceSunken : t.accent,
        border: `1px solid ${isMax ? t.border : t.accent}`,
        color: isMax ? t.textMute : t.accentInk, cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        opacity: isMax ? 0.5 : 1,
      }}><Icon name="plus" size={14} color={isMax ? t.textMute : t.accentInk} /></button>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// DECK DOCTOR
// ─────────────────────────────────────────────────────────────
function DoctorScreen({ t, setScreen }) {
  const grade = 'B+';
  const score = 78;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: t.bg, color: t.text }}>
      <TopBar
        t={t} title="Deck Doctor" subtitle="vs Standard 2026-05"
        left={<IconBtn t={t} icon="arrowLeft" onClick={() => setScreen('home')} ariaLabel="Back" />}
        right={<IconBtn t={t} icon="info" ariaLabel="About" />}
      />

      <div style={{ flex: 1, overflow: 'auto', padding: '12px 16px 80px' }}>
        {/* Deck pick */}
        <button style={{
          width: '100%', textAlign: 'left', cursor: 'pointer',
          display: 'flex', alignItems: 'center', gap: 12,
          padding: 10, background: t.surface,
          border: `1px solid ${t.border}`, borderRadius: t.radiusLg,
          color: t.text,
        }}>
          <CardPlaceholder t={t} w={42} h={58} type="fire" name="Charizard" attached={0} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: t.fontBody, fontSize: 10.5, color: t.textMute, textTransform: 'uppercase', letterSpacing: '0.08em' }}>Analyzing</div>
            <div style={{ fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 16, color: t.text, marginTop: 1 }}>Charizard ex</div>
          </div>
          <Icon name="chevronDown" size={16} color={t.textMute} />
        </button>

        {/* Grade card */}
        <div style={{
          marginTop: 12,
          padding: '18px 18px 16px',
          borderRadius: t.radiusLg,
          background: t.surfaceRaised, border: `1px solid ${t.border}`,
          display: 'flex', alignItems: 'center', gap: 16,
        }}>
          {/* circular grade */}
          <div style={{ position: 'relative', width: 92, height: 92, flex: '0 0 auto' }}>
            <svg width="92" height="92" viewBox="0 0 92 92">
              <circle cx="46" cy="46" r="38" fill="none" stroke={t.surfaceSunken} strokeWidth="8" />
              <circle cx="46" cy="46" r="38" fill="none" stroke={t.accent} strokeWidth="8"
                strokeDasharray={`${(score / 100) * (2 * Math.PI * 38)} ${2 * Math.PI * 38}`}
                strokeLinecap="round"
                transform="rotate(-90 46 46)" />
            </svg>
            <div style={{
              position: 'absolute', inset: 0, display: 'flex',
              flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
            }}>
              <div style={{ fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 28, color: t.text, lineHeight: 1 }}>{grade}</div>
              <div style={{ fontFamily: t.fontMono, fontSize: 10, color: t.textMute, marginTop: 1 }}>{score}/100</div>
            </div>
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 16, color: t.text, letterSpacing: '-0.01em' }}>Strong attacker base</div>
            <div style={{ fontFamily: t.fontBody, fontSize: 12.5, color: t.textDim, marginTop: 4, lineHeight: 1.4 }}>
              Reliable evolution chain, decent search. Bench coverage thin against single-prize disruption.
            </div>
          </div>
        </div>

        {/* Game plan */}
        <Section t={t} title="Game plan" icon="target">
          <ol style={{ margin: 0, padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              'Bench Charmander T1, attach Fire, pass.',
              'Rare Candy into Charizard ex turn 2 if possible.',
              'Pidgeot ex for consistency — search Fire energy.',
              'Spread damage with Burning Darkness once 4+ benched.',
            ].map((step, i) => (
              <li key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                <div style={{
                  width: 22, height: 22, borderRadius: 999, flex: '0 0 auto',
                  background: t.accent, color: t.accentInk,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: t.fontMono, fontWeight: 700, fontSize: 11,
                }}>{i + 1}</div>
                <span style={{ fontFamily: t.fontBody, fontSize: 13, color: t.textDim, lineHeight: 1.4 }}>{step}</span>
              </li>
            ))}
          </ol>
        </Section>

        {/* Problems */}
        <Section t={t} title="Watchouts" icon="shield">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {[
              { sev: 'high', text: 'Only 2 Rare Candy — Stage 2 setup variance.' },
              { sev: 'med', text: 'No tech vs Snorlax-stall.' },
              { sev: 'low', text: 'Iono / Boss split feels light for late-game.' },
            ].map((p, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '8px 10px',
                background: t.surfaceSunken, borderRadius: t.radius,
                border: `1px solid ${t.border}`,
                borderLeft: `3px solid ${p.sev === 'high' ? t.danger : p.sev === 'med' ? t.accent3 : t.textMute}`,
              }}>
                <div style={{
                  fontFamily: t.fontMono, fontSize: 9, fontWeight: 700,
                  color: p.sev === 'high' ? t.danger : p.sev === 'med' ? t.accent3 : t.textMute,
                  textTransform: 'uppercase', letterSpacing: '0.08em',
                  width: 38,
                }}>{p.sev}</div>
                <span style={{ fontFamily: t.fontBody, fontSize: 12.5, color: t.text, flex: 1 }}>{p.text}</span>
              </div>
            ))}
          </div>
        </Section>

        {/* Matchups */}
        <Section t={t} title="Matchups" icon="trophy">
          {[
            { name: 'Gardevoir ex', wr: 62, bias: 'fav' },
            { name: 'Lugia VSTAR', wr: 48, bias: 'even' },
            { name: 'Roaring Moon', wr: 38, bias: 'unfav' },
            { name: 'Snorlax Stall', wr: 22, bias: 'unfav' },
          ].map((m, i) => {
            const color = m.bias === 'fav' ? t.ok : m.bias === 'even' ? t.accent3 : t.danger;
            return (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0', borderBottom: i < 3 ? `1px solid ${t.border}` : 'none' }}>
                <div style={{ flex: 1, fontFamily: t.fontBody, fontWeight: 600, fontSize: 13, color: t.text }}>{m.name}</div>
                <div style={{ width: 96, height: 6, background: t.surfaceSunken, borderRadius: 999, overflow: 'hidden', position: 'relative' }}>
                  <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${m.wr}%`, background: color }} />
                  <div style={{ position: 'absolute', left: '50%', top: -2, bottom: -2, width: 1, background: t.textMute }} />
                </div>
                <div style={{ width: 36, textAlign: 'right', fontFamily: t.fontMono, fontWeight: 700, fontSize: 12, color }}>{m.wr}%</div>
              </div>
            );
          })}
        </Section>
      </div>

      <BottomNav t={t} screen="doctor" setScreen={setScreen} />
    </div>
  );
}

function Section({ t, title, icon, children }) {
  return (
    <div style={{ marginTop: 18 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
        {icon && <Icon name={icon} size={13} color={t.accent} />}
        <div style={{ fontFamily: t.fontDisplay, fontWeight: 700, fontSize: 12, letterSpacing: '0.06em', textTransform: 'uppercase', color: t.textDim }}>{title}</div>
      </div>
      <Surface t={t} style={{ padding: 14 }}>
        {children}
      </Surface>
    </div>
  );
}

Object.assign(window, {
  TopBar, IconBtn, BottomNav,
  HomeScreen, PreGameScreen, DeckSlot, ToggleRow, Divider,
  BuilderScreen, MiniBreakdown, Stepper,
  DoctorScreen, Section,
});
