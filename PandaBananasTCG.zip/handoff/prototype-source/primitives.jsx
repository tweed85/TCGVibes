// Primitives shared across all three direction themes.
// Mark = panda/banana geometric brand mark (original — not Pokémon).
// CardPlaceholder = striped 'card art' placeholder per content guidelines.
// Type icons = simple geometric energy chips.

// ─────────────────────────────────────────────────────────────
// Brand mark — abstract panda head built around a banana smile.
// Pure geometry, no Pokémon, original.
// ─────────────────────────────────────────────────────────────
function Mark({ size = 28, ink = '#fff', accent = '#ffd60a', bg = 'transparent' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 48 48" style={{ display: 'block' }}>
      {bg !== 'transparent' && <rect width="48" height="48" rx="12" fill={bg} />}
      {/* panda ears */}
      <circle cx="13" cy="13" r="6" fill={ink} />
      <circle cx="35" cy="13" r="6" fill={ink} />
      {/* head */}
      <circle cx="24" cy="26" r="14" fill={ink} />
      {/* eye patches */}
      <ellipse cx="18" cy="23" rx="3" ry="4" fill={bg === 'transparent' ? '#1a0b3d' : bg} />
      <ellipse cx="30" cy="23" rx="3" ry="4" fill={bg === 'transparent' ? '#1a0b3d' : bg} />
      {/* eyes */}
      <circle cx="18" cy="24" r="1.2" fill={ink} />
      <circle cx="30" cy="24" r="1.2" fill={ink} />
      {/* banana smile */}
      <path
        d="M16 30 Q24 38 32 30 Q30 33 24 33 Q18 33 16 30 Z"
        fill={accent}
        stroke={accent}
        strokeWidth="0.6"
        strokeLinejoin="round"
      />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Wordmark (Mark + name)
// ─────────────────────────────────────────────────────────────
function Wordmark({ t, size = 22 }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <Mark size={size + 6} ink={t.text} accent={t.accent3} bg={t.surfaceSolid.includes('linear') ? '#000' : t.surfaceSolid} />
      <div style={{
        fontFamily: t.fontDisplay,
        fontWeight: 700,
        fontSize: size,
        letterSpacing: '-0.02em',
        color: t.text,
        lineHeight: 1,
      }}>
        PandaBananas<span style={{ color: t.accent }}>TCG</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Striped card placeholder. The art is a striped fill;
// the card chrome (HP, type chip, name) varies by theme.
// ─────────────────────────────────────────────────────────────
function CardPlaceholder({
  t,
  w = 88,
  h = 124,
  name = 'Card Art',
  hp = 130,
  type = 'fire',
  energy = 1,
  attached = 0,
  faceDown = false,
  active = false,
  label = null,
  density = 'comfortable',
  style = {},
}) {
  const stripeColors = {
    fire:      ['#ff7a3d', '#c63a1a'],
    water:     ['#3fb6ff', '#1968b3'],
    grass:     ['#5fd16a', '#2a7a35'],
    lightning: ['#ffd445', '#caa01a'],
    psychic:   ['#cc7af6', '#6b29a0'],
    fighting:  ['#d4863a', '#7a4615'],
    dark:      ['#3a3a4a', '#15151c'],
    metal:     ['#bdc6d2', '#6b7480'],
    colorless: ['#e8e1cf', '#a89b78'],
  };
  const [c1, c2] = stripeColors[type] || stripeColors.colorless;

  const innerPad = density === 'compact' ? 4 : 6;
  const corner = density === 'compact' ? 8 : 10;

  return (
    <div style={{
      width: w,
      height: h,
      borderRadius: corner,
      background: faceDown ? t.cardBg : `repeating-linear-gradient(135deg, ${c1} 0px, ${c1} 5px, ${c2} 5px, ${c2} 10px)`,
      boxShadow: active ? t.glow : t.shadowCard,
      position: 'relative',
      overflow: 'hidden',
      flex: '0 0 auto',
      transform: active ? 'translateY(-2px)' : 'none',
      transition: 'transform 120ms ease, box-shadow 120ms ease',
      ...style,
    }}>
      {/* card chrome */}
      {!faceDown && (
        <div style={{
          position: 'absolute', inset: innerPad,
          display: 'flex', flexDirection: 'column',
          justifyContent: 'space-between',
        }}>
          {/* Top row: HP + type */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div style={{
              fontFamily: t.fontMono, fontSize: 9, fontWeight: 700,
              color: '#fff',
              background: 'rgba(0,0,0,0.45)',
              padding: '2px 5px', borderRadius: 6,
              lineHeight: 1, letterSpacing: '0.02em',
            }}>HP {hp}</div>
            <TypeDot type={type} size={12} />
          </div>

          {/* Center: "card art" stripe band label */}
          <div style={{
            background: 'rgba(0,0,0,0.55)',
            color: '#fff',
            fontFamily: t.fontMono, fontSize: 8,
            textAlign: 'center', padding: '2px 4px',
            borderRadius: 3, margin: '0 -2px',
            textTransform: 'uppercase', letterSpacing: '0.08em',
          }}>card art</div>

          {/* Bottom: name + energy attached */}
          <div style={{
            background: 'rgba(0,0,0,0.55)',
            color: '#fff',
            fontFamily: t.fontBody, fontWeight: 600, fontSize: 9.5,
            padding: '3px 5px', borderRadius: 5,
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            gap: 4,
          }}>
            <span style={{
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
            }}>{name}</span>
            {attached > 0 && (
              <span style={{ display: 'flex', gap: 1 }}>
                {Array.from({ length: Math.min(attached, 3) }).map((_, i) => (
                  <span key={i} style={{
                    width: 6, height: 6, borderRadius: 999,
                    background: ENERGY_COLOR[type] || '#fff',
                    boxShadow: '0 0 0 1px rgba(0,0,0,0.4)',
                  }} />
                ))}
              </span>
            )}
          </div>
        </div>
      )}
      {/* face-down: brand mark watermark */}
      {faceDown && (
        <div style={{
          position: 'absolute', inset: 0, display: 'flex',
          alignItems: 'center', justifyContent: 'center',
          opacity: 0.6,
        }}>
          <Mark size={Math.min(w, h) * 0.5} ink="#fff" accent={t.accent3} />
        </div>
      )}
      {label && (
        <div style={{
          position: 'absolute', top: 4, left: 4,
          background: t.accent, color: t.accentInk,
          fontFamily: t.fontMono, fontSize: 8, fontWeight: 700,
          padding: '2px 5px', borderRadius: 4, letterSpacing: '0.04em',
          textTransform: 'uppercase',
        }}>{label}</div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Energy / type chips
// ─────────────────────────────────────────────────────────────
const ENERGY_COLOR = {
  fire:      '#ef4444',
  water:     '#3b82f6',
  grass:     '#22c55e',
  lightning: '#eab308',
  psychic:   '#a855f7',
  fighting:  '#b45309',
  dark:      '#1f2937',
  metal:     '#94a3b8',
  colorless: '#cbd5e1',
};

function TypeDot({ type = 'fire', size = 14 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: 999,
      background: ENERGY_COLOR[type] || '#ccc',
      boxShadow: '0 0 0 1.5px rgba(0,0,0,0.5), inset 0 1px 1px rgba(255,255,255,0.4)',
    }} />
  );
}

function EnergyPip({ type, count = 1, t }) {
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      background: 'rgba(0,0,0,0.25)',
      borderRadius: 999, padding: '2px 7px 2px 4px',
    }}>
      <TypeDot type={type} size={10} />
      <span style={{
        fontFamily: t.fontMono, fontSize: 10, fontWeight: 700, color: t.text,
      }}>{count}</span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Generic button
// ─────────────────────────────────────────────────────────────
function Btn({ t, children, variant = 'default', size = 'md', icon, onClick, disabled, style = {}, fullWidth = false, ariaLabel }) {
  const sizes = {
    sm: { h: 32, px: 12, fs: 12, gap: 6 },
    md: { h: 44, px: 16, fs: 14, gap: 8 },
    lg: { h: 52, px: 20, fs: 16, gap: 10 },
  };
  const s = sizes[size];
  const variants = {
    default: {
      background: t.surfaceRaised,
      color: t.text,
      border: `1px solid ${t.border}`,
      boxShadow: 'none',
    },
    primary: {
      background: t.accent,
      color: t.accentInk,
      border: 'none',
      boxShadow: t.name === 'Arcade' ? '0 0 0 1px rgba(255,255,255,0.15), 0 6px 16px rgba(255,45,142,0.45)' : '0 2px 0 rgba(0,0,0,0.18)',
    },
    ghost: {
      background: 'transparent',
      color: t.textDim,
      border: 'none',
    },
    outline: {
      background: 'transparent',
      color: t.text,
      border: `1.5px solid ${t.borderStrong}`,
    },
    danger: {
      background: t.danger,
      color: '#fff',
      border: 'none',
    },
  };
  return (
    <button
      aria-label={ariaLabel}
      onClick={onClick}
      disabled={disabled}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: s.gap,
        height: s.h, padding: `0 ${s.px}px`,
        borderRadius: t.radius,
        fontFamily: t.fontBody, fontWeight: 600, fontSize: s.fs,
        letterSpacing: t.name === 'Arcade' ? '0.01em' : '-0.005em',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.45 : 1,
        width: fullWidth ? '100%' : 'auto',
        transition: 'transform 90ms ease, box-shadow 120ms ease',
        ...variants[variant],
        ...style,
      }}
    >
      {icon}
      {children}
    </button>
  );
}

// ─────────────────────────────────────────────────────────────
// Surface card (theme-aware panel)
// ─────────────────────────────────────────────────────────────
function Surface({ t, children, raised = false, sunken = false, style = {}, onClick }) {
  return (
    <div onClick={onClick} style={{
      background: sunken ? t.surfaceSunken : raised ? t.surfaceRaised : t.surface,
      border: `1px solid ${t.border}`,
      borderRadius: t.radiusLg,
      ...style,
    }}>{children}</div>
  );
}

// ─────────────────────────────────────────────────────────────
// Simple inline icons (lucide-style strokes)
// ─────────────────────────────────────────────────────────────
function Icon({ name, size = 18, color = 'currentColor', strokeWidth = 2 }) {
  const common = {
    width: size, height: size, viewBox: '0 0 24 24',
    fill: 'none', stroke: color, strokeWidth, strokeLinecap: 'round', strokeLinejoin: 'round',
  };
  const paths = {
    play: <polygon points="6 4 20 12 6 20 6 4" fill={color} />,
    home: <><path d="M3 11l9-7 9 7v9a2 2 0 0 1-2 2h-4v-7h-6v7H5a2 2 0 0 1-2-2z" /></>,
    stethoscope: <><path d="M11 2v6a4 4 0 0 0 8 0V2" /><circle cx="20" cy="14" r="3" /><path d="M15 8a8 8 0 0 1-8 8 5 5 0 0 1-5-5v-2" /></>,
    cards: <><rect x="4" y="3" width="12" height="16" rx="2" /><path d="M8 7v8M12 7v8" /><path d="M20 8v10a2 2 0 0 1-2 2H10" /></>,
    history: <><path d="M3 12a9 9 0 1 0 3-6.7L3 8" /><polyline points="3 3 3 8 8 8" /><path d="M12 8v4l3 2" /></>,
    settings: <><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h0a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v0a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z" /></>,
    chevron: <polyline points="9 18 15 12 9 6" />,
    chevronDown: <polyline points="6 9 12 15 18 9" />,
    plus: <><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></>,
    minus: <line x1="5" y1="12" x2="19" y2="12" />,
    search: <><circle cx="11" cy="11" r="7" /><line x1="20" y1="20" x2="16.65" y2="16.65" /></>,
    close: <><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></>,
    bolt: <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" fill={color} />,
    swords: <><polyline points="14.5 17.5 3 6 3 3 6 3 17.5 14.5" /><line x1="13" y1="19" x2="19" y2="13" /><line x1="16" y1="16" x2="20" y2="20" /><line x1="19" y1="21" x2="21" y2="19" /></>,
    retreat: <><path d="M9 14l-4-4 4-4" /><path d="M5 10h11a4 4 0 0 1 4 4v4" /></>,
    hand: <><path d="M18 11V6a2 2 0 0 0-4 0v5" /><path d="M14 10V4a2 2 0 0 0-4 0v6" /><path d="M10 10.5V6a2 2 0 0 0-4 0v9" /><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.94L2.5 16.5a2.5 2.5 0 0 1 4-3l1.5 1.5" /></>,
    deck: <><rect x="4" y="3" width="14" height="18" rx="2" /><path d="M8 7h6M8 11h6M8 15h4" /></>,
    sparkle: <><path d="M12 2l1.7 5.3L19 9l-5.3 1.7L12 16l-1.7-5.3L5 9l5.3-1.7L12 2z" /></>,
    grid: <><rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="14" y="14" width="7" height="7" /><rect x="3" y="14" width="7" height="7" /></>,
    list: <><line x1="8" y1="6" x2="21" y2="6" /><line x1="8" y1="12" x2="21" y2="12" /><line x1="8" y1="18" x2="21" y2="18" /><circle cx="3.5" cy="6" r="1" /><circle cx="3.5" cy="12" r="1" /><circle cx="3.5" cy="18" r="1" /></>,
    filter: <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" />,
    info: <><circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="8" /><line x1="12" y1="12" x2="12" y2="16" /></>,
    check: <polyline points="20 6 9 17 4 12" />,
    arrow: <><line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" /></>,
    arrowLeft: <><line x1="19" y1="12" x2="5" y2="12" /><polyline points="12 19 5 12 12 5" /></>,
    shield: <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />,
    trophy: <><path d="M8 21h8M12 17v4" /><path d="M7 4h10v6a5 5 0 0 1-10 0V4z" /><path d="M21 5h-4M3 5h4M4 5a3 3 0 0 0 3 3M20 5a3 3 0 0 1-3 3" /></>,
    target: <><circle cx="12" cy="12" r="10" /><circle cx="12" cy="12" r="6" /><circle cx="12" cy="12" r="2" /></>,
  };
  return <svg {...common}>{paths[name] || null}</svg>;
}

// Pill chip
function Pill({ t, tone = 'default', children, icon, style = {} }) {
  const tones = {
    default: { bg: t.surfaceSunken, fg: t.textDim, border: t.border },
    accent: { bg: 'transparent', fg: t.accent, border: t.accent },
    accent2: { bg: 'transparent', fg: t.accent2, border: t.accent2 },
    ok: { bg: 'transparent', fg: t.ok, border: t.ok },
    warn: { bg: 'transparent', fg: t.accent3, border: t.accent3 },
    danger: { bg: 'transparent', fg: t.danger, border: t.danger },
    solid: { bg: t.accent, fg: t.accentInk, border: t.accent },
  };
  const c = tones[tone];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      background: c.bg, color: c.fg,
      border: `1px solid ${c.border}`,
      borderRadius: 999,
      padding: '3px 9px',
      fontFamily: t.fontBody, fontWeight: 600, fontSize: 11,
      letterSpacing: '0.01em',
      ...style,
    }}>
      {icon}
      {children}
    </span>
  );
}

Object.assign(window, {
  Mark, Wordmark, CardPlaceholder, TypeDot, EnergyPip, Btn, Surface, Icon, Pill,
  ENERGY_COLOR,
});
