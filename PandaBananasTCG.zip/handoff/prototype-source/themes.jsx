// Three direction tokens for PandaBananasTCG mobile redesign.
// Each theme provides a flat token bag the screens consume.
// Kept inline-style-friendly so the same screen code paints differently per theme.

const THEMES = {
  arcade: {
    name: 'Arcade',
    tagline: 'Vibrant, energetic, gaming UI',
    // Backgrounds
    bg: 'radial-gradient(120% 80% at 50% 0%, #2a0e5e 0%, #120631 55%, #07021a 100%)',
    bgSolid: '#120631',
    surface: 'linear-gradient(180deg, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0.02) 100%), #1c0d44',
    surfaceSolid: '#1c0d44',
    surfaceRaised: 'linear-gradient(180deg, #2b1764 0%, #1c0d44 100%)',
    surfaceSunken: '#0e0530',
    border: 'rgba(255,255,255,0.10)',
    borderStrong: 'rgba(255,255,255,0.18)',
    // Text
    text: '#fff8ff',
    textDim: '#cdb9f5',
    textMute: '#8a7bba',
    // Accents — vivid game palette
    accent: '#ff2d8e',         // hot pink primary
    accentInk: '#fff',
    accent2: '#00e0ff',        // electric cyan
    accent3: '#ffd60a',        // lightning yellow
    danger: '#ff5b6e',
    ok: '#39e08a',
    // Card surface (the placeholder "card art")
    cardBg: 'linear-gradient(135deg, #ff2d8e 0%, #7b3cff 50%, #00e0ff 100%)',
    cardStripe: 'rgba(255,255,255,0.18)',
    cardInk: '#fff',
    // Typography
    fontDisplay: '"Bricolage Grotesque", "Space Grotesk", system-ui, sans-serif',
    fontBody: '"Geist", "Inter", system-ui, -apple-system, sans-serif',
    fontMono: '"JetBrains Mono", ui-monospace, monospace',
    // Shape
    radius: 14,
    radiusLg: 22,
    radiusFull: 999,
    // Shadows / glow
    shadowCard: '0 8px 24px rgba(255, 45, 142, 0.25), 0 0 0 1px rgba(255,255,255,0.08)',
    shadowFloat: '0 18px 40px rgba(0,0,0,0.55)',
    glow: '0 0 0 2px rgba(255,45,142,0.45), 0 0 24px rgba(255,45,142,0.5)',
    // Status bar matches dark
    statusDark: true,
  },

  paper: {
    name: 'Paper',
    tagline: 'Warm, tactile, soft shadows',
    bg: '#f0e8d7',
    bgSolid: '#f0e8d7',
    surface: '#fbf6ea',
    surfaceSolid: '#fbf6ea',
    surfaceRaised: '#ffffff',
    surfaceSunken: '#e8dcc4',
    border: 'rgba(58, 40, 22, 0.10)',
    borderStrong: 'rgba(58, 40, 22, 0.20)',
    text: '#2a1f15',
    textDim: '#5d4a36',
    textMute: '#8a7457',
    accent: '#b8472b',         // terracotta
    accentInk: '#fff7ec',
    accent2: '#2e6a6b',        // deep teal
    accent3: '#c98a1f',        // amber
    danger: '#a8341a',
    ok: '#3b7a4a',
    cardBg: 'repeating-linear-gradient(45deg, #c98a1f 0px, #c98a1f 6px, #b8472b 6px, #b8472b 12px)',
    cardStripe: 'rgba(255, 247, 236, 0.25)',
    cardInk: '#fff7ec',
    fontDisplay: '"Instrument Serif", "Newsreader", Georgia, serif',
    fontBody: '"Geist", "Manrope", system-ui, -apple-system, sans-serif',
    fontMono: '"JetBrains Mono", ui-monospace, monospace',
    radius: 12,
    radiusLg: 18,
    radiusFull: 999,
    shadowCard: '0 1px 0 rgba(58,40,22,0.04), 0 6px 16px rgba(58,40,22,0.10)',
    shadowFloat: '0 12px 30px rgba(58,40,22,0.18)',
    glow: '0 0 0 2px rgba(184, 71, 43, 0.35)',
    statusDark: false,
  },

  premium: {
    name: 'Hybrid',
    tagline: 'Premium, refined, modern dark',
    bg: 'linear-gradient(180deg, #0e1018 0%, #07090f 100%)',
    bgSolid: '#0b0d13',
    surface: '#13161f',
    surfaceSolid: '#13161f',
    surfaceRaised: 'linear-gradient(180deg, #1a1e2a 0%, #13161f 100%)',
    surfaceSunken: '#0a0c12',
    border: 'rgba(255,255,255,0.06)',
    borderStrong: 'rgba(255,255,255,0.12)',
    text: '#ecedf2',
    textDim: '#9aa0ad',
    textMute: '#5d6470',
    accent: '#7b5cff',          // electric violet
    accentInk: '#fff',
    accent2: '#4ad6e0',         // cyan
    accent3: '#f5c451',         // gold
    danger: '#ff6376',
    ok: '#3ddc97',
    cardBg: 'repeating-linear-gradient(45deg, #7b5cff 0px, #7b5cff 6px, #4ad6e0 6px, #4ad6e0 12px)',
    cardStripe: 'rgba(255,255,255,0.25)',
    cardInk: '#fff',
    fontDisplay: '"Outfit", "Geist", system-ui, sans-serif',
    fontBody: '"Geist", "Outfit", system-ui, -apple-system, sans-serif',
    fontMono: '"JetBrains Mono", ui-monospace, monospace',
    radius: 12,
    radiusLg: 18,
    radiusFull: 999,
    shadowCard: '0 1px 0 rgba(255,255,255,0.04) inset, 0 8px 22px rgba(0,0,0,0.50)',
    shadowFloat: '0 18px 40px rgba(0,0,0,0.55)',
    glow: '0 0 0 1.5px rgba(123,92,255,0.6), 0 0 18px rgba(123,92,255,0.35)',
    statusDark: true,
  },
};

window.THEMES = THEMES;
